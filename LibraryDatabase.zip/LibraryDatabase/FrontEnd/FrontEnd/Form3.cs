﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace EmmaFrontEnd
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void buildAndDisplay(string pTitle)

        {

            //Overview:

            //Searches the DB for the title user entered

            //Links that title to Faculty Owner and Availability

            //Prints on ListBox

            try

            {

                //Step 1: Create object from local variables

                SqlConnection objConnection = new SqlConnection("Data Source=(local);initial catalog=TheBestCPSCLibrary; User ID=sa;Password=Sql2017$");

                SqlCommand objCommand = new SqlCommand();

                SqlDataReader objReader;

                //Step 2:  Assign property values to Coomand object

                objCommand.Connection = objConnection;

                objCommand.CommandText = "westrumTitleSearch";

                objCommand.CommandType = CommandType.StoredProcedure;

                objCommand.Parameters.AddWithValue("@title", pTitle);//Name of

                //parameter(s) must match name in SP... data types must also match



                //Step 2: Open Database conection

                objConnection.Open();



                //Step 3:  Instruct DBMS to execute SQL...

                //         this also instantiates a DataReader object

                objReader = objCommand.ExecuteReader();


                //Step 4:  Fetch data from result set 1 row at a time (connection open throughout)

                while (objReader.Read())

                {

                    listBox1.Items.Add(objReader[0].ToString().PadRight(50) + objReader[1].ToString().PadRight(55) + objReader[2].ToString().PadLeft(5));

                }

                objConnection.Close(); //unnecessary because local variable loses scope and lifetime at end of

                //event method

            }
            catch (Exception e)

            {

                MessageBox.Show(e.ToString());

            }

        }

        private void button1_Click(object sender, EventArgs e)
        {

            try

            {

                if (textBox1.Text.Length > 0)

                {

                    string id = textBox1.Text;

                    buildAndDisplay(id);

                    button1.Enabled = false;

                }

                else

                {

                    MessageBox.Show("Please Enter A BookTitle");

                    textBox1.Focus();

                }

            }

            catch

            {

                MessageBox.Show("Enter valid BookTitle");

                textBox1.Text = "";

                textBox1.Focus();

            }

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}

