﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace EmmaFrontEnd
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            try
            {
                int pComID = Convert.ToInt32(textBox1.Text); // user input
                // open connection
                SqlConnection objConnection = new SqlConnection("Data Source=(local);initial catalog=TheBestCPSCLibrary; User ID=sa;Password=Sql2017$");
                SqlCommand objCommand = new SqlCommand();
                SqlDataReader objReader;

                // call stored procedure
                objCommand.Connection = objConnection;
                objCommand.CommandText = "showComment";
                objCommand.CommandType = CommandType.StoredProcedure;
                objCommand.Parameters.AddWithValue("@comid", pComID);

                objConnection.Open();

                objReader = objCommand.ExecuteReader();

                //read results
                while (objReader.Read())
                {
                    listBox1.Items.Add("Comment: " + objReader[0].ToString() + "\t\t" + "Title: " + objReader[1].ToString());

                }
            }
            catch
            {
                MessageBox.Show("Error");
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
