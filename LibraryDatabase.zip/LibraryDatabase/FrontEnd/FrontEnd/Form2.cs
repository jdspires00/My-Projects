﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace EmmaFrontEnd
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        private void Form2_Load(object sender, EventArgs e)
        {
            

        }
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                //declare local variables for connection
                SqlConnection objConnection = new SqlConnection("Data Source=(local);initial catalog=TheBestCPSCLibrary; User ID=sa;Password=Sql2017$");
                SqlCommand objCommand = new SqlCommand("SELECT name,create_date FROM Sys.tables", objConnection);
                SqlDataReader objReader;

                //assign property values
                objCommand.Connection = objConnection;
                objCommand.CommandText = "listCheckedOut";
                objCommand.CommandType = CommandType.StoredProcedure;

                //open connection
                objConnection.Open();

                //Tell DBMS to execute SP and instantiate DataReader Class
                objReader = objCommand.ExecuteReader();

                //read the objreader to the list box, with formatting
                while (objReader.Read())
                {
                    listBox1.Items.Add(objReader[0].ToString().PadRight(50) + objReader[1].ToString().PadRight(30) + objReader[2].ToString().PadRight(20) + objReader[3].ToString().PadRight(10) + objReader[4].ToString().PadLeft(5));

                }

            }
            catch (Exception c)
            {

                MessageBox.Show(c.ToString());
            }
        }

    }
}
